// app/store/product/[slug]/page.tsx

import Link from "next/link";
import { notFound } from "next/navigation";
import { PRODUCTS } from "@/data/products";
import { formatIDR } from "@/lib/format";

export default function ProductPage({ params }: { params: { slug: string } }) {
  const p = PRODUCTS.find((x) => x.slug === params.slug);
  if (!p) return notFound();

  return (
    <main className="p-8 max-w-2xl">
      <Link href="/store" className="underline">
        ← Kembali
      </Link>
      <h1 className="text-3xl font-bold mt-4">{p.title}</h1>
      {p.desc && <p className="text-gray-700 mt-2">{p.desc}</p>}
      <p className="mt-4 text-xl">Rp {formatIDR(p.price)}</p>
      <button className="mt-6 rounded-lg border px-4 py-2">
        Tambah ke Cart
      </button>
    </main>
  );
}
