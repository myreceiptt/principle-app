// app/store/page.tsx

import Link from "next/link";
import { PRODUCTS } from "@/data/products";
import { formatIDR } from "@/lib/format";

export default function StorePage() {
  return (
    <main className="p-8">
      <Link href="/" className="underline">
        ← Back
      </Link>
      <h1 className="text-3xl font-bold mt-4">Store</h1>
      <p className="text-gray-600 mt-2">PRINCIPLE Spaces</p>
      <ul className="mt-6 grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
        {PRODUCTS.map((p) => (
          <li key={p.id} className="rounded-lg border p-4">
            <h2 className="font-semibold">{p.title}</h2>
            <p className="text-gray-600 mt-1">Rp {formatIDR(p.price)}</p>
            <Link
              className="inline-block mt-3 underline"
              href={`/store/product/${p.slug}`}>
              Details
            </Link>
          </li>
        ))}
      </ul>
    </main>
  );
}
