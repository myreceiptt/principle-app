// app/spaces/page.tsx

import Link from "next/link";

export default function Page() {
  return (
    <main className="p-8">
      <Link href="/" className="underline">
        ← Back
      </Link>
      <h1 className="text-3xl font-bold mt-4">Spaces</h1>
      <p className="text-gray-600 mt-2">PRINCIPLE Spaces</p>
      <ul className="mt-6 grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
        <li className="rounded-lg border p-4">
          <h2 className="font-semibold">AIUEO</h2>
          <p className="text-gray-600 mt-1">Rp 1.000.000</p>
          <Link
            className="inline-block mt-3 underline"
            href={`/store/product/#`}>
            Details
          </Link>
        </li>
        <li className="rounded-lg border p-4">
          <h2 className="font-semibold">VWXYZ</h2>
          <p className="text-gray-600 mt-1">Rp 2.500.000</p>
          <Link
            className="inline-block mt-3 underline"
            href={`/store/product/#`}>
            Details
          </Link>
        </li>
      </ul>
    </main>
  );
}
