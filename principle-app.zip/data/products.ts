// data/products.ts

export type Product = {
  id: string;
  slug: string;
  title: string;
  desc?: string;
  price: number; // IDR
  image?: string;
};

export const PRODUCTS: Product[] = [
  {
    id: "1",
    slug: "tshirt-principle",
    title: "T-Shirt PRINCIPLE",
    desc: "Kaos katun 24s.",
    price: 149000,
  },
  {
    id: "2",
    slug: "cap-principle",
    title: "Cap PRINCIPLE",
    desc: "Topi snapback.",
    price: 99000,
  },
];
