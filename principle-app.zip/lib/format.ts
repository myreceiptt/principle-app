// lib/format.ts

export const formatIDR = (n: number) =>
  n.toLocaleString("id-ID", { maximumFractionDigits: 0 });
